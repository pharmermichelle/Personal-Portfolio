loop_cats
