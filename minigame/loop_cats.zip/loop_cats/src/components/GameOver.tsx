import React from 'react';
import { Cat } from '../types';

interface GameOverProps {
  score: number;
  selectedCat: Cat;
  onRestart: () => void;
  onUpgrade: (upgrade: 'speed' | 'jump' | 'slipperResistance') => void;
  onBackToMenu: () => void;
}

const GameOver: React.FC<GameOverProps> = ({ 
  score, 
  selectedCat, 
  onRestart, 
  onUpgrade, 
  onBackToMenu 
}) => {
  const upgrades = [
    {
      id: 'speed' as const,
      name: 'Speed Boost',
      description: 'Run faster through the house',
      icon: '⚡',
      color: 'from-yellow-400 to-orange-500',
      bgColor: 'bg-yellow-50'
    },
    {
      id: 'jump' as const,
      name: 'Super Jump',
      description: 'Jump higher over obstacles',
      icon: '⬆️',
      color: 'from-green-400 to-blue-500',
      bgColor: 'bg-green-50'
    },
    {
      id: 'slipperResistance' as const,
      name: 'Slipper Resistance',
      description: 'Slip less on water spills',
      icon: '🧦',
      color: 'from-purple-400 to-pink-500',
      bgColor: 'bg-purple-50'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl border border-white/20 p-8 max-w-lg w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">🏁 Race Complete!</h1>
          <p className="text-xl text-gray-600 mb-6">
            {selectedCat.name} finished the race!
          </p>
          <div className="text-6xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4">
            {score}
          </div>
          <p className="text-gray-500 text-lg">Final Score</p>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            🎯 Choose an Upgrade
          </h2>
          <div className="space-y-3">
            {upgrades.map((upgrade) => (
              <button
                key={upgrade.id}
                onClick={() => onUpgrade(upgrade.id)}
                className={`w-full p-5 bg-gradient-to-r ${upgrade.color} text-white rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-400/50 border border-white/20`}
              >
                <div className="flex items-center space-x-4">
                  <div className="text-3xl bg-white/20 rounded-full w-12 h-12 flex items-center justify-center">{upgrade.icon}</div>
                  <div className="text-left flex-1">
                    <h3 className="font-bold text-lg">{upgrade.name}</h3>
                    <p className="text-sm opacity-90 leading-relaxed">{upgrade.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex space-x-4">
          <button
            onClick={onRestart}
            className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 text-white py-4 px-6 rounded-2xl font-semibold hover:from-purple-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-400/50 shadow-lg"
          >
            🏃‍♂️ Race Again
          </button>
          <button
            onClick={onBackToMenu}
            className="flex-1 bg-slate-200 text-gray-800 py-4 px-6 rounded-2xl font-semibold hover:bg-slate-300 transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-slate-300/50 shadow-lg"
          >
            🐱 Change Cat
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameOver;