import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Cat, GameState, Obstacle, Player } from '../types';
import { generateObstacle, checkCollision, updatePlayer, calculateScore } from '../utils/gameLogic';
import { drawBackground, drawPlayer, drawObstacle, drawUI } from '../utils/renderer';

interface GameCanvasProps {
  selectedCat: Cat;
  onGameEnd: (score: number) => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ selectedCat, onGameEnd }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [gameState, setGameState] = useState<GameState>({
    currentRoom: 'kitchen',
    lap: 1,
    score: 0,
    isPlaying: true,
    isPaused: false,
    selectedCat,
    upgrades: { speed: 0, jump: 0, slipperResistance: 0 }
  });
  
  const [player, setPlayer] = useState<Player>({
    x: 100,
    y: 0,
    velocityY: 0,
    isJumping: false,
    cat: selectedCat,
    upgrades: { speed: 0, jump: 0, slipperResistance: 0 }
  });
  
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [keys, setKeys] = useState<Set<string>>(new Set());
  const [roomProgress, setRoomProgress] = useState(0);
  const [obstaclesPassed, setObstaclesPassed] = useState(0);
  const [slowEffect, setSlowEffect] = useState(0);
  const [lastObstacleTime, setLastObstacleTime] = useState(0);

  const canvasWidth = 800;
  const canvasHeight = 400;

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
      }
      setKeys(prev => new Set(prev).add(e.code));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.code);
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Handle touch input
  const handleTouch = useCallback(() => {
    setKeys(prev => new Set(prev).add('Space'));
    setTimeout(() => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete('Space');
        return newKeys;
      });
    }, 100);
  }, []);

  // Generate obstacles
  useEffect(() => {
    if (!gameState.isPlaying || gameState.isPaused) return;

    const gameLoop = () => {
      const now = Date.now();
      
      // Generate obstacles more frequently and ensure they appear
      if (now - lastObstacleTime > 1500 && obstacles.length < 4) {
        const roomIndex = ['kitchen', 'hallway', 'living-room'].indexOf(gameState.currentRoom);
        const newObstacle = generateObstacle(canvasWidth, roomIndex);
        setObstacles(prev => [...prev, newObstacle]);
        setLastObstacleTime(now);
      }
    };

    const interval = setInterval(gameLoop, 100);
    return () => clearInterval(interval);
  }, [obstacles.length, gameState.currentRoom, canvasWidth, gameState.isPlaying, gameState.isPaused, lastObstacleTime]);

  // Game loop
  useEffect(() => {
    if (!gameState.isPlaying || gameState.isPaused) return;

    const gameLoop = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Clear canvas
      ctx.clearRect(0, 0, canvasWidth, canvasHeight);

      // Update player
      setPlayer(prevPlayer => updatePlayer(prevPlayer, keys, canvasHeight));

      // Update obstacles
      setObstacles(prevObstacles => {
        const speed = selectedCat.baseSpeed + (player.upgrades.speed * 0.3);
        return prevObstacles
          .map(obstacle => ({ ...obstacle, x: obstacle.x - speed }))
          .filter(obstacle => obstacle.x > -100);
      });

      // Check collisions
      obstacles.forEach(obstacle => {
        if (checkCollision(player, obstacle) && !obstacle.passed) {
          // Handle special effects
          if (obstacle.type === 'yarn') {
            // Yarn ball slows down the cat temporarily
            setSlowEffect(120); // 2 seconds at 60fps
            obstacle.passed = true;
            return;
          }
          
          // Handle collision based on obstacle type and upgrades
          if (obstacle.type === 'water' && player.upgrades.slipperResistance > 0) {
            // Reduced slip effect with slipper resistance
            setSlowEffect(30);
            obstacle.passed = true;
            return;
          }
          
          // End game or apply penalty
          setGameState(prev => ({ ...prev, isPlaying: false }));
          onGameEnd(calculateScore(gameState.lap, obstaclesPassed));
          return;
        }
        
        if (obstacle.x + obstacle.width < player.x && !obstacle.passed) {
          obstacle.passed = true;
          setObstaclesPassed(prev => prev + 1);
        }
      });

      // Update slow effect
      if (slowEffect > 0) {
        setSlowEffect(prev => prev - 1);
      }

      // Update room progress
      setRoomProgress(prev => {
        const speedMultiplier = slowEffect > 0 ? 0.5 : 1;
        const newProgress = prev + (selectedCat.baseSpeed + player.upgrades.speed * 0.3) * speedMultiplier;
        if (newProgress >= 2000) {
          // Move to next room
          const rooms = ['kitchen', 'hallway', 'living-room'] as const;
          const currentIndex = rooms.indexOf(gameState.currentRoom);
          const nextIndex = (currentIndex + 1) % rooms.length;
          
          setGameState(prevState => ({
            ...prevState,
            currentRoom: rooms[nextIndex],
            lap: nextIndex === 0 ? prevState.lap + 1 : prevState.lap,
            score: calculateScore(nextIndex === 0 ? prevState.lap + 1 : prevState.lap, obstaclesPassed)
          }));
          
          // Check if completed 3 laps
          if (nextIndex === 0 && gameState.lap >= 3) {
            setGameState(prev => ({ ...prev, isPlaying: false }));
            onGameEnd(calculateScore(gameState.lap, obstaclesPassed));
            return 0;
          }
          
          return 0;
        }
        return newProgress;
      });

      // Draw everything
      drawBackground(ctx, gameState, canvasWidth, canvasHeight);
      drawPlayer(ctx, player);
      obstacles.forEach(obstacle => drawObstacle(ctx, obstacle));
      drawUI(ctx, gameState, canvasWidth, canvasHeight);

      animationRef.current = requestAnimationFrame(gameLoop);
    };

    animationRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [gameState, player, obstacles, keys, obstaclesPassed, selectedCat, roomProgress, slowEffect, onGameEnd]);

  return (
    <div className="game-container">
      <canvas
        ref={canvasRef}
        width={canvasWidth}
        height={canvasHeight}
        onClick={handleTouch}
        onTouchStart={handleTouch}
        className="rounded-2xl shadow-2xl bg-white border-4 border-white/20"
        style={{ maxWidth: '100vw', maxHeight: '100vh' }}
      />
    </div>
  );
};

export default GameCanvas;