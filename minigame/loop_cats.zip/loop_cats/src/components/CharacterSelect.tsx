import React from 'react';
import { Cat } from '../types';
import { cats } from '../utils/gameLogic';

interface CharacterSelectProps {
  onSelectCat: (cat: Cat) => void;
}

const CharacterSelect: React.FC<CharacterSelectProps> = ({ onSelectCat }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl border border-white/20 p-8 max-w-md w-full">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          🐱 Loop Cats
        </h1>
        <p className="text-center text-gray-600 mb-8 text-lg">
          Choose your racing cat!
        </p>
        
        <div className="space-y-4">
          {cats.map((cat) => (
            <button
              key={cat.name}
              onClick={() => onSelectCat(cat)}
              className="w-full p-6 bg-gradient-to-r from-slate-50 to-slate-100 rounded-2xl hover:from-slate-100 hover:to-slate-200 transition-all duration-300 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-4 focus:ring-purple-400/50 border border-slate-200/50"
            >
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-full flex items-center justify-center shadow-lg border-2 border-white" style={{ backgroundColor: cat.color }}>
                  <div className="text-3xl">
                    {cat.size === 'fat' ? '🐱' : '🐈'}
                  </div>
                </div>
                <div className="text-left flex-1">
                  <h3 className="text-2xl font-bold text-gray-800 mb-1">{cat.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 leading-relaxed">{cat.description}</p>
                  <div className="flex space-x-4 text-xs text-gray-500">
                    <span className="bg-blue-100 px-2 py-1 rounded-full">⚡ Speed: {cat.baseSpeed}</span>
                    <span className="bg-green-100 px-2 py-1 rounded-full">⬆️ Jump: {cat.jumpHeight}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
        
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 mb-2">
            🏠 Race through the house: Kitchen → Hallway → Living Room
          </p>
          <p className="text-sm text-gray-500 mt-1">
            🏆 Complete 3 laps to earn upgrades!
          </p>
        </div>
      </div>
    </div>
  );
};

export default CharacterSelect;