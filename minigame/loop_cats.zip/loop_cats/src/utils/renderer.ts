import { Player, Obstacle, GameState } from '../types';
import { rooms, obstacleTypes } from './gameLogic';

export function drawBackground(ctx: CanvasRenderingContext2D, gameState: GameState, canvasWidth: number, canvasHeight: number): void {
  const roomIndex = ['kitchen', 'hallway', 'living-room'].indexOf(gameState.currentRoom);
  const room = rooms[roomIndex];
  
  // Room-specific backgrounds
  if (gameState.currentRoom === 'kitchen') {
    // Kitchen background - warm yellows
    const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
    gradient.addColorStop(0, '#fef3c7');
    gradient.addColorStop(1, '#fbbf24');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    
    // Kitchen tiles
    ctx.fillStyle = '#f3f4f6';
    for (let x = 0; x < canvasWidth; x += 40) {
      for (let y = canvasHeight - 100; y < canvasHeight; y += 40) {
        ctx.fillRect(x, y, 38, 38);
      }
    }
    
    // Kitchen cabinets
    ctx.fillStyle = '#8b5cf6';
    ctx.fillRect(0, 50, canvasWidth, 80);
    ctx.fillStyle = '#7c3aed';
    for (let x = 20; x < canvasWidth; x += 100) {
      ctx.fillRect(x, 60, 60, 60);
    }
    
  } else if (gameState.currentRoom === 'hallway') {
    // Hallway background - cool blues
    const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
    gradient.addColorStop(0, '#dbeafe');
    gradient.addColorStop(1, '#93c5fd');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    
    // Hallway carpet
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, canvasHeight - 100, canvasWidth, 100);
    
    // Hallway pattern
    ctx.fillStyle = '#b91c1c';
    for (let x = 0; x < canvasWidth; x += 60) {
      ctx.fillRect(x, canvasHeight - 90, 30, 80);
    }
    
  } else if (gameState.currentRoom === 'living-room') {
    // Living room background - warm purples
    const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
    gradient.addColorStop(0, '#f3e8ff');
    gradient.addColorStop(1, '#c084fc');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    
    // Living room couch
    ctx.fillStyle = '#4b5563';
    ctx.fillRect(50, 100, 200, 80);
    ctx.fillRect(40, 90, 220, 20);
    
    // Coffee table
    ctx.fillStyle = '#92400e';
    ctx.fillRect(300, 140, 120, 60);
    
    // Carpet
    ctx.fillStyle = '#059669';
    ctx.fillRect(0, canvasHeight - 100, canvasWidth, 100);
  }
  
  // Room indicator
  ctx.fillStyle = '#374151';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'center';
  const roomName = gameState.currentRoom.replace('-', ' ').toUpperCase();
  ctx.fillText(`🏠 ${roomName} 🏠`, canvasWidth / 2, 40);
}

export function drawPlayer(ctx: CanvasRenderingContext2D, player: Player): void {
  const catWidth = player.cat.size === 'fat' ? 50 : 35;
  const catHeight = player.cat.size === 'fat' ? 40 : 30;
  
  // Cat body
  ctx.fillStyle = player.cat.color;
  ctx.beginPath();
  ctx.ellipse(
    player.x + catWidth / 2,
    player.y + catHeight / 2,
    catWidth / 2,
    catHeight / 2,
    0,
    0,
    2 * Math.PI
  );
  ctx.fill();
  
  // Cat head
  ctx.beginPath();
  ctx.arc(
    player.x + catWidth / 2,
    player.y + catHeight / 4,
    catWidth / 3,
    0,
    2 * Math.PI
  );
  ctx.fill();
  
  // Eyes
  ctx.fillStyle = '#1f2937';
  ctx.beginPath();
  ctx.arc(player.x + catWidth / 2 - 8, player.y + catHeight / 4 - 5, 3, 0, 2 * Math.PI);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(player.x + catWidth / 2 + 8, player.y + catHeight / 4 - 5, 3, 0, 2 * Math.PI);
  ctx.fill();
  
  // Nose
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.arc(player.x + catWidth / 2, player.y + catHeight / 4 + 3, 2, 0, 2 * Math.PI);
  ctx.fill();
  
  // Ears
  ctx.fillStyle = player.cat.color;
  ctx.beginPath();
  ctx.moveTo(player.x + catWidth / 2 - 12, player.y + catHeight / 4 - 15);
  ctx.lineTo(player.x + catWidth / 2 - 5, player.y + catHeight / 4 - 25);
  ctx.lineTo(player.x + catWidth / 2 - 3, player.y + catHeight / 4 - 15);
  ctx.fill();
  
  ctx.beginPath();
  ctx.moveTo(player.x + catWidth / 2 + 12, player.y + catHeight / 4 - 15);
  ctx.lineTo(player.x + catWidth / 2 + 5, player.y + catHeight / 4 - 25);
  ctx.lineTo(player.x + catWidth / 2 + 3, player.y + catHeight / 4 - 15);
  ctx.fill();
}

export function drawObstacle(ctx: CanvasRenderingContext2D, obstacle: Obstacle): void {
  const config = obstacleTypes[obstacle.type];
  ctx.fillStyle = config.color;
  
  if (obstacle.type === 'laundry') {
    // Draw laundry basket
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    ctx.fillStyle = '#4b5563';
    ctx.fillRect(obstacle.x + 5, obstacle.y + 5, obstacle.width - 10, obstacle.height - 10);
  } else if (obstacle.type === 'water') {
    // Draw water spill
    ctx.beginPath();
    ctx.ellipse(
      obstacle.x + obstacle.width / 2,
      obstacle.y + obstacle.height / 2,
      obstacle.width / 2,
      obstacle.height / 2,
      0,
      0,
      2 * Math.PI
    );
    ctx.fill();
  } else if (obstacle.type === 'food') {
    // Draw food
    ctx.beginPath();
    ctx.arc(
      obstacle.x + obstacle.width / 2,
      obstacle.y + obstacle.height / 2,
      obstacle.width / 2,
      0,
      2 * Math.PI
    );
    ctx.fill();
  } else if (obstacle.type === 'hotwheels') {
    // Draw Hot Wheels car
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    // Wheels
    ctx.fillStyle = '#1f2937';
    ctx.beginPath();
    ctx.arc(obstacle.x + 8, obstacle.y + obstacle.height - 3, 4, 0, 2 * Math.PI);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(obstacle.x + obstacle.width - 8, obstacle.y + obstacle.height - 3, 4, 0, 2 * Math.PI);
    ctx.fill();
  } else if (obstacle.type === 'legos') {
    // Draw Lego blocks
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    // Lego studs
    ctx.fillStyle = '#16a34a';
    for (let i = 0; i < 2; i++) {
      for (let j = 0; j < 2; j++) {
        ctx.beginPath();
        ctx.arc(
          obstacle.x + 6 + i * 12,
          obstacle.y + 6 + j * 12,
          3,
          0,
          2 * Math.PI
        );
        ctx.fill();
      }
    }
  } else if (obstacle.type === 'crafts') {
    // Draw craft supplies (scissors and glue)
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    // Scissors handles
    ctx.fillStyle = '#7c3aed';
    ctx.beginPath();
    ctx.arc(obstacle.x + 10, obstacle.y + 10, 6, 0, 2 * Math.PI);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(obstacle.x + 25, obstacle.y + 10, 6, 0, 2 * Math.PI);
    ctx.fill();
  } else if (obstacle.type === 'yarn') {
    // Draw yarn ball
    ctx.beginPath();
    ctx.arc(
      obstacle.x + obstacle.width / 2,
      obstacle.y + obstacle.height / 2,
      obstacle.width / 2,
      0,
      2 * Math.PI
    );
    ctx.fill();
    
    // Yarn strands
    ctx.strokeStyle = '#ea580c';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(
      obstacle.x + obstacle.width / 2,
      obstacle.y + obstacle.height / 2,
      obstacle.width / 3,
      0,
      Math.PI
    );
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(
      obstacle.x + obstacle.width / 2,
      obstacle.y + obstacle.height / 2,
      obstacle.width / 4,
      Math.PI,
      2 * Math.PI
    );
    ctx.stroke();
  }
}

export function drawUI(ctx: CanvasRenderingContext2D, gameState: GameState, canvasWidth: number, canvasHeight: number): void {
  // Modern UI background with subtle gradient
  const gradient = ctx.createLinearGradient(0, 0, 0, 120);
  gradient.addColorStop(0, 'rgba(0, 0, 0, 0.8)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0.4)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvasWidth, 120);
  
  // Score with modern styling
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 32px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'left';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  ctx.shadowBlur = 4;
  ctx.shadowOffsetX = 2;
  ctx.shadowOffsetY = 2;
  ctx.fillText(`🏆 ${gameState.score}`, 20, 40);
  
  // Reset shadow
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  
  // Lap counter with progress bar
  ctx.fillStyle = '#e5e7eb';
  ctx.font = 'bold 20px system-ui, -apple-system, sans-serif';
  ctx.fillText(`Lap ${gameState.lap}/3`, 20, 70);
  
  // Progress bar background
  ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.fillRect(20, 80, 150, 8);
  
  // Progress bar fill
  const progress = (gameState.lap - 1) / 3;
  const progressGradient = ctx.createLinearGradient(20, 80, 170, 88);
  progressGradient.addColorStop(0, '#10b981');
  progressGradient.addColorStop(1, '#059669');
  ctx.fillStyle = progressGradient;
  ctx.fillRect(20, 80, 150 * progress, 8);
  
  // Room indicator with modern badge
  const roomName = gameState.currentRoom.replace('-', ' ').toUpperCase();
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.fillRect(canvasWidth - 200, 15, 180, 35);
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 18px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(`🏠 ${roomName}`, canvasWidth - 110, 37);
  
  // Cat name with avatar
  if (gameState.selectedCat) {
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px system-ui, -apple-system, sans-serif';
    ctx.textAlign = 'right';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
    ctx.shadowBlur = 4;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    const catEmoji = gameState.selectedCat.size === 'fat' ? '🐱' : '🐈';
    ctx.fillText(`${catEmoji} ${gameState.selectedCat.name}`, canvasWidth - 20, 40);
    
    // Reset shadow
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
  }
  
  // Modern controls hint with background
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fillRect(0, canvasHeight - 40, canvasWidth, 40);
  
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('🎮 TAP or SPACEBAR to jump over obstacles', canvasWidth / 2, canvasHeight - 15);
}