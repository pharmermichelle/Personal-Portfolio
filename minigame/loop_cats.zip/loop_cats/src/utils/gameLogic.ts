import { Cat, Obstacle, Player } from '../types';

export const cats: Cat[] = [
  {
    name: 'Bennett',
    size: 'fat',
    baseSpeed: 2,
    jumpHeight: 100,
    color: '#9ca3af',
    description: 'A chunky boy who loves treats but moves steadily'
  },
  {
    name: 'Regina',
    size: 'tiny',
    baseSpeed: 3,
    jumpHeight: 120,
    color: '#a1a1aa',
    description: 'A speedy little girl who can jump high'
  }
];

export const rooms = [
  { 
    name: 'kitchen', 
    color: '#fef3c7', 
    obstacles: ['food', 'water', 'crafts'],
    description: 'Watch out for spilled treats!'
  },
  { 
    name: 'hallway', 
    color: '#e0e7ff', 
    obstacles: ['laundry', 'hotwheels', 'legos'],
    description: 'Laundry baskets block the way!'
  },
  { 
    name: 'living-room', 
    color: '#f3e8ff', 
    obstacles: ['laundry', 'water', 'yarn'],
    description: 'Cozy but cluttered!'
  }
];

export const obstacleTypes = {
  laundry: { width: 60, height: 40, color: '#6b7280' },
  water: { width: 40, height: 20, color: '#3b82f6' },
  food: { width: 30, height: 30, color: '#f59e0b' },
  hotwheels: { width: 35, height: 15, color: '#ef4444' },
  legos: { width: 25, height: 25, color: '#22c55e' },
  crafts: { width: 45, height: 35, color: '#a855f7' },
  yarn: { width: 40, height: 40, color: '#f97316', effect: 'slow' as const }
};

export function generateObstacle(canvasWidth: number, roomIndex: number): Obstacle {
  const room = rooms[roomIndex];
  const possibleTypes = room.obstacles as Array<'laundry' | 'water' | 'food' | 'hotwheels' | 'legos' | 'crafts' | 'yarn'>;
  const type = possibleTypes[Math.floor(Math.random() * possibleTypes.length)];
  const obstacle = obstacleTypes[type];
  
  return {
    id: Math.random().toString(36).substr(2, 9),
    x: canvasWidth + 50,
    y: 350 - obstacle.height,
    width: obstacle.width,
    height: obstacle.height,
    type,
    passed: false,
    effect: obstacle.effect || 'none'
  };
}

export function checkCollision(player: Player, obstacle: Obstacle): boolean {
  const playerWidth = player.cat.size === 'fat' ? 50 : 35;
  const playerHeight = player.cat.size === 'fat' ? 40 : 30;
  
  return (
    player.x < obstacle.x + obstacle.width &&
    player.x + playerWidth > obstacle.x &&
    player.y < obstacle.y + obstacle.height &&
    player.y + playerHeight > obstacle.y
  );
}

export function updatePlayer(player: Player, keys: Set<string>, canvasHeight: number): Player {
  const gravity = 0.6;
  const jumpForce = -12;
  const groundY = canvasHeight - 120;
  
  // Handle jumping
  if ((keys.has('Space') || keys.has('ArrowUp')) && !player.isJumping) {
    player.velocityY = jumpForce * (1 + player.upgrades.jump * 0.2);
    player.isJumping = true;
  }
  
  // Apply gravity
  player.velocityY += gravity;
  player.y += player.velocityY;
  
  // Ground collision
  if (player.y >= groundY) {
    player.y = groundY;
    player.velocityY = 0;
    player.isJumping = false;
  }
  
  return player;
}

export function calculateScore(lap: number, obstaclesPassed: number): number {
  return (lap * 100) + (obstaclesPassed * 10);
}