import React, { useState } from 'react';
import CharacterSelect from './components/CharacterSelect';
import GameCanvas from './components/GameCanvas';
import GameOver from './components/GameOver';
import { Cat } from './types';

type GameScreen = 'character-select' | 'game' | 'game-over';

function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('character-select');
  const [selectedCat, setSelectedCat] = useState<Cat | null>(null);
  const [finalScore, setFinalScore] = useState(0);
  const [upgrades, setUpgrades] = useState({
    speed: 0,
    jump: 0,
    slipperResistance: 0
  });

  const handleSelectCat = (cat: Cat) => {
    setSelectedCat(cat);
    setCurrentScreen('game');
  };

  const handleGameEnd = (score: number) => {
    setFinalScore(score);
    setCurrentScreen('game-over');
  };

  const handleUpgrade = (upgrade: 'speed' | 'jump' | 'slipperResistance') => {
    setUpgrades(prev => ({
      ...prev,
      [upgrade]: prev[upgrade] + 1
    }));
    setCurrentScreen('game');
  };

  const handleRestart = () => {
    setCurrentScreen('game');
  };

  const handleBackToMenu = () => {
    setSelectedCat(null);
    setUpgrades({ speed: 0, jump: 0, slipperResistance: 0 });
    setCurrentScreen('character-select');
  };

  return (
    <div className="app">
      {currentScreen === 'character-select' && (
        <CharacterSelect onSelectCat={handleSelectCat} />
      )}
      
      {currentScreen === 'game' && selectedCat && (
        <GameCanvas
          selectedCat={selectedCat}
          onGameEnd={handleGameEnd}
        />
      )}
      
      {currentScreen === 'game-over' && selectedCat && (
        <GameOver
          score={finalScore}
          selectedCat={selectedCat}
          onRestart={handleRestart}
          onUpgrade={handleUpgrade}
          onBackToMenu={handleBackToMenu}
        />
      )}
    </div>
  );
}

export default App;