export interface Cat {
  name: string;
  size: 'fat' | 'tiny';
  baseSpeed: number;
  jumpHeight: number;
  color: string;
  description: string;
}

export interface GameState {
  currentRoom: 'kitchen' | 'hallway' | 'living-room';
  lap: number;
  score: number;
  isPlaying: boolean;
  isPaused: boolean;
  selectedCat: Cat | null;
  upgrades: {
    speed: number;
    jump: number;
    slipperResistance: number;
  };
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'laundry' | 'water' | 'food' | 'hotwheels' | 'legos' | 'crafts' | 'yarn';
  passed: boolean;
  effect?: 'slow' | 'jump' | 'none';
}

export interface Player {
  x: number;
  y: number;
  velocityY: number;
  isJumping: boolean;
  cat: Cat;
  upgrades: {
    speed: number;
    jump: number;
    slipperResistance: number;
  };
}